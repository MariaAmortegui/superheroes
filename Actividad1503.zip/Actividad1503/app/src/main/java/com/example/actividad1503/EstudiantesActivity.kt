package com.example.actividad1503

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class EstudiantesActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_estudiantes)
    }
}